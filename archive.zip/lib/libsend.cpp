#include <pthread.h>
#include <cstdlib>
#include <map>
#include <cstdint>
#include "lib.h"
#include "utils.h"
#include "protocol.h"
#include <cassert>
#include <poll.h>
#include <sys/timerfd.h>
#include <string.h>

using namespace std;

std::map<int, struct connection *> cons;

struct pollfd data_fds[MAX_CONNECTIONS];
/* Used for timers per connection */
struct pollfd timer_fds[MAX_CONNECTIONS];
int fdmax = 0;

static int nr_ferestre = 150;
static int verify_connection[MAX_CONNECTIONS] = {0};

int send_data(int conn_id, char *buffer, int len)
{
    int size = 0;
    struct connection *current_connection = cons[conn_id];
    pthread_mutex_lock(&cons[conn_id]->con_lock);

    char *data = buffer;
    int bytes_remaining = len;

    while (bytes_remaining > 0) {
        int packet_len;
        if (bytes_remaining < MAX_DATA_SIZE)
            packet_len = bytes_remaining;
        else packet_len = MAX_DATA_SIZE;

        char buffer[MAX_SEGMENT_SIZE];
        poli_tcp_data_hdr *header = (poli_tcp_data_hdr *)buffer;
        header->conn_id = conn_id;
        header->len = packet_len;
        header->seq_num = current_connection->next_to_send;
        header->seq_num = current_connection->next_to_send;
        header->type = 3;
        memcpy(buffer + sizeof(poli_tcp_data_hdr), data, packet_len);

        std::vector<char> pkt(buffer, buffer + sizeof(poli_tcp_data_hdr) + packet_len);
        current_connection->sent_packet[current_connection->next_to_send] = pkt;
        current_connection->next_to_send++;

        data = data + packet_len;
        bytes_remaining = bytes_remaining - packet_len;
    }
    /* We will write code here as to not have sync problems with sender_handler */
    pthread_mutex_unlock(&cons[conn_id]->con_lock);
    return len;
}

void *sender_handler(void *arg)
{
    int res = 0;
    char buf[MAX_SEGMENT_SIZE];

    while (1) {

        if (cons.size() == 0) {
            continue;
        }
        int conn_id = -1;
        do {
            res = recv_message_or_timeout(buf, MAX_SEGMENT_SIZE, &conn_id);
            if (res == -1) {
                for (auto &kv : cons) {
                    struct connection *current_connection = kv.second;
                    pthread_mutex_lock(&current_connection->con_lock);
                    for (auto &pkt : current_connection->sent_packet) {
                        sendto(current_connection->sockfd, pkt.second.data(), pkt.second.size(), 0, (struct sockaddr *)&current_connection->servaddr, sizeof(current_connection->servaddr));
                    }
                    pthread_mutex_unlock(&current_connection->con_lock);
                }
            }
        } while(res == -14);

        if (conn_id == -1)
            continue;
        if (cons.find(conn_id) == cons.end())
            continue;

        struct connection *current_connection = cons[conn_id];
        pthread_mutex_lock(&cons[conn_id]->con_lock);

        if (res >= (int) sizeof(struct poli_tcp_ctrl_hdr)) {
            poli_tcp_ctrl_hdr *header = (poli_tcp_ctrl_hdr *)buf;
            if (header->protocol_id == POLI_PROTOCOL_ID && header->type == 0) {
                int value_ack = header->ack_num;
                for (int s = current_connection->base; s <= value_ack; s++) {
                    current_connection->sent_packet.erase(s);
                }
                if (value_ack + 1 > current_connection->base) {
                    current_connection->base = value_ack + 1;
                }
                if (header->recv_window > 0)
                current_connection->max_window_seq = header->recv_window;

                for (auto &kv : current_connection->sent_packet) {
                    if (kv.first >= current_connection->base && kv.first < current_connection->base + current_connection->max_window_seq) {
                        sendto(current_connection->sockfd, kv.second.data(), kv.second.size(), 0, (struct sockaddr *)&current_connection->servaddr, sizeof(current_connection->servaddr));
                    }
                }
                if (verify_connection[conn_id] == 0 && current_connection->sent_packet.empty() && current_connection->base > 0 && current_connection->base == current_connection->next_to_send) {
                    poli_tcp_data_hdr header;
                    memset(&header, 0, sizeof(header));
                    header.conn_id = conn_id;
                    header.protocol_id = POLI_PROTOCOL_ID;
                    header.type = 4;

                    sendto(current_connection->sockfd, &header, sizeof(header), 0, (struct sockaddr *)&current_connection->servaddr, sizeof(current_connection->servaddr));
                    verify_connection[conn_id] = 1;
                }
            }
        }
        /* Handle segment received from the receiver. We use this between locks
        as to not have synchronization issues with the send_data calls which are
        on the main thread */
        pthread_mutex_unlock(&cons[conn_id]->con_lock);
    }
    return NULL;
}

int setup_connection(uint32_t ip, uint16_t port)
{
    /* Implement the sender part of the Three Way Handshake. Blocks
    until the connection is established */

    struct connection *con = (struct connection *)malloc(sizeof(struct connection));
    new (con) struct connection();
    int conn_id = 0;
    con->sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    con->servaddr.sin_addr.s_addr = ip;
    con->servaddr.sin_family = AF_INET;
    con->servaddr.sin_port = port;

    poli_tcp_ctrl_hdr send_syn;
    memset(&send_syn, 0, sizeof(send_syn));
    send_syn.conn_id = 0;
    send_syn.protocol_id = POLI_PROTOCOL_ID;
    send_syn.type = 2;

    sendto(con->sockfd, &send_syn, sizeof(send_syn), 0, (struct sockaddr *)&con->servaddr, sizeof(con->servaddr));

    char buffer[MAX_SEGMENT_SIZE];
    while (1) {
        struct sockaddr_in resp;
        socklen_t clen = sizeof(resp);
        recvfrom(con->sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *)&resp, &clen);
        poli_tcp_ctrl_hdr *header = (poli_tcp_ctrl_hdr *)buffer;
        if (header->type == 1) {
            if (header->ack_num != 0) {
                con->servaddr.sin_port = header->ack_num;
            }
            if (header->recv_window > 0) {
                con->max_window_seq = header->recv_window;
            } else {
                con->max_window_seq = nr_ferestre;
            }
            break;
        }
    }
    
    conn_id = fdmax;

    poli_tcp_ctrl_hdr send_last_ack;
    memset(&send_last_ack, 0, sizeof(send_last_ack));
    send_last_ack.conn_id = conn_id;
    send_last_ack.protocol_id = POLI_PROTOCOL_ID;
    send_last_ack.type = 0;
    sendto(con->sockfd, &send_last_ack, sizeof(send_last_ack), 0, (struct sockaddr *)&con->servaddr, sizeof(con->servaddr));
    
    con->base = 0;
    con->next_to_send = 0;
    con->conn_id = conn_id;
    verify_connection[conn_id] = 0;
    /* // This can be used to set a timer on a socket 
    struct timeval tv;
    tv.tv_sec = 2;
    tv.tv_usec = 100000;
    if (setsockopt(con->sockfd, SOL_SOCKET, SO_RCVTIMEO,&tv,sizeof(tv)) < 0) {
        perror("Error");
    } */

    /* We will send the SYN on 8031. Then we will receive a SYN-ACK with the connection
     * port. We can use con->sockfd for both cases, but we will need to update server_addr
     * with the port received via SYN-ACK */

    /* Since we can have multiple connection, we want to know if data is available
       on the socket used by a given connection. We use POLL for this */
    data_fds[fdmax].fd = con->sockfd;    
    data_fds[fdmax].events = POLLIN;    
    
    /* This creates a timer and sets it to trigger every 1 sec. We use this
       to know if a timeout has happend on our connection */
    timer_fds[fdmax].fd = timerfd_create(CLOCK_REALTIME,  0);    
    timer_fds[fdmax].events = POLLIN;    
    struct itimerspec spec;     
    spec.it_value.tv_sec = 0;    
    spec.it_value.tv_nsec = 40000000;    
    spec.it_interval.tv_sec = 0;    
    spec.it_interval.tv_nsec = 40000000;    
    timerfd_settime(timer_fds[fdmax].fd, 0, &spec, NULL);    
    fdmax++;


    pthread_mutex_init(&con->con_lock, NULL);
    pthread_cond_init(&con->wait_data, NULL);
    cons.insert({conn_id, con});

    DEBUG_PRINT("Connection established!");

    return conn_id;
}

void init_sender(int speed, int delay)
{
    pthread_t thread1;
    int ret;

    /* Create a thread that will*/
    ret = pthread_create( &thread1, NULL, sender_handler, NULL);
    assert(ret == 0);
}
